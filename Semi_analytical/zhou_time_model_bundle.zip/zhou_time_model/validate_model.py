"""Reproducible checks for the coupled kernel, time history and controls.

Run alongside zhou_three_panel.py: python validate_model.py
Spatial refinement is reported as sensitivity, not an assertion that N=12
is a converged reference or that the three-panel solution is fully accurate.
"""
import json
from dataclasses import replace
from pathlib import Path

import numpy as np
from scipy.integrate import quad
from scipy.special import exp1

from zhou_three_panel import (
    HOUR, PSI, Parameters, diagnostics, simulate, step_response,
)


def validate():
    p = Parameters()
    checks = {}

    # Independent adaptive spatial quadrature, including the self-panel.
    kernel_errors = []
    for age_h in (0.01, 1.0, 60.0):
        age = age_h * HOUR
        expected = np.zeros((3, 3))
        coefficient = p.mu / (4 * np.pi * p.k * p.h)
        for i, x in enumerate(p.centers_m):
            for j in range(3):
                lo, hi = p.vertices_m[j:j+2]
                total = 0.0
                for a, b in ((lo, hi), (2*p.xf-hi, 2*p.xf-lo)):
                    points = [x] if a < x < b else None
                    value, _ = quad(lambda s: exp1((x-s)**2/(4*p.eta*age)),
                                    a, b, points=points, epsabs=1e-9, epsrel=1e-10)
                    total += value
                expected[i, j] = coefficient * total
        kernel_errors.append(float(np.max(abs(step_response(p, age)-expected))
                                   / np.max(abs(expected))))
    checks["kernel_vs_independent_quadrature_max_norm_relative_error"] = max(kernel_errors)
    assert max(kernel_errors) < 1e-10
    assert np.all(step_response(p, 0.0) == 0)

    # Constant flux over arbitrary time intervals must collapse to A(t)q.
    edges = np.array([0.0, 0.01, 0.1, 1.0, 3.0, 60.0]) * HOUR
    q = np.array([1.0, 2.0, 4.0]) * 1e-6
    weights = step_response(p, edges[-1]-edges[:-1]) - step_response(p, edges[-1]-edges[1:])
    convolved = np.einsum("mij,j->i", weights, q)
    direct = step_response(p, edges[-1]) @ q
    error = float(np.max(abs(convolved-direct)) / np.max(abs(direct)))
    checks["constant_flux_history_telescoping_relative_error"] = error
    assert error < 1e-13

    # Half-wing image must equal explicit summation over the six real panels.
    full = replace(p, xf_ft=420.0, n_panels=6, include_other_wing=False)
    A6 = step_response(full, 60*HOUR)
    explicit = A6[:3, :3] + A6[:3, 3:][:, ::-1]
    image = step_response(p, 60*HOUR)
    checks["opposite_wing_vs_explicit_six_panels_relative_error"] = float(
        np.max(abs(image-explicit)) / np.max(abs(explicit)))
    assert checks["opposite_wing_vs_explicit_six_panels_relative_error"] < 1e-13

    base = simulate(p)
    report = diagnostics(base)
    checks["base_diagnostics"] = report
    assert report["max_scaled_linear_residual"] < 1e-12
    assert report["max_center_pressure_mismatch_psi"] < 1e-7
    assert report["max_Darcy_mismatch_psi"] < 1e-7
    assert report["max_continuity_relative_error"] < 1e-12
    assert report["max_well_balance_relative_error"] < 1e-12
    assert np.allclose(base.p_pa[:, -1]/PSI, p.pwf_psi, atol=1e-8)
    assert np.all(base.panel_rate_stb_day[base.report_indices] > 0)
    assert np.all(np.diff(base.total_rate_stb_day[base.report_indices]) < 0)
    # Coarse-grid startup artifacts are retained and reported, never clamped.

    fine_time = simulate(p, points_per_decade=120)
    baseline_rate = base.total_rate_stb_day[base.report_indices]
    time_difference = abs(fine_time.total_rate_stb_day[fine_time.report_indices]
                          / baseline_rate - 1)
    checks["time_refinement_60_to_120_points_per_decade"] = {
        "times_h": base.reports_h.tolist(),
        "relative_total_rate_change": time_difference.tolist(),
        "max_relative_total_rate_change": float(time_difference.max()),
    }
    assert time_difference.max() < 0.005

    fine_space = simulate(replace(p, n_panels=12))
    space_difference = abs(fine_space.total_rate_stb_day[fine_space.report_indices]
                           / baseline_rate - 1)
    checks["spatial_sensitivity_3_to_12_panels_per_wing"] = {
        "times_h": base.reports_h.tolist(),
        "relative_total_rate_change": space_difference.tolist(),
        "max_relative_total_rate_change": float(space_difference.max()),
        "interpretation": "Sensitivity only; 12 panels are not an established converged reference.",
    }

    rate = simulate(replace(p, control="rate"))
    rate_error = float(np.max(abs(rate.total_rate_stb_day-25.0)))
    checks["fixed_total_rate_max_error_STB_day"] = rate_error
    checks["fixed_rate_BHP_at_requested_times_psi"] = (rate.p_pa[rate.report_indices, -1]/PSI).tolist()
    assert rate_error < 1e-8
    assert np.all(np.diff(rate.p_pa[rate.report_indices, -1]) < 0)
    checks["status"] = "passed; coarse spatial discretization limits are explicitly reported"
    return checks


if __name__ == "__main__":
    result = validate()
    destination = Path(__file__).resolve().parent / "validation.json"
    destination.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
