# Zhou (2014) 单裂缝：从三网格矩阵到时间推进

从 `zhou_time_walkthrough.ipynb` 开始最方便：它自带全部模型代码和已运行的示例输出，不依赖旁边的 `.py` 文件。适合 Windows VS Code + Jupyter。脚本 `zhou_three_panel.py` 提供同一套求解器，便于以后继续扩展。

## 运行

在当前 Python / Jupyter 环境安装 `requirements.txt` 中的四个包。Notebook 用户可以在一个新单元中运行 `%pip install numpy scipy matplotlib pandas`，然后按顺序运行 notebook。

命令行：

```bash
python -m pip install -r requirements.txt
python zhou_three_panel.py --times 1 2 3 5 10 60
python zhou_three_panel.py --control rate --rate 25 --out results_rate
python validate_model.py
```

**时间输入统一为小时。** 如果希望输出 1、2、3、5、10、60 天，在 notebook 中用 `report_times_h = 24*np.array([1,2,3,5,10,60], dtype=float)`。

## 本次计算的范围

- 单相、微可压缩、物性不变；全穿透裂缝。
- 储层采用二维、侧向无限域 Green 函数，垂向不流动。这里未实现论文的有限矩形侧边界。
- 裂缝内部采用准稳态 Darcy 流，无非 Darcy 项、无裂缝储集、无井筒储集。
- 一个对称双翼裂缝，只对半翼列未知数，但 Green 函数同时包含另一半翼的汇流影响。
- 每个 panel 的入流沿该 panel 均匀、在每个时间区间内常数；在区间右端匹配压力。三网格用于学习/核对方程，并非宣称已经定量复现论文图件。

论文依据：Zhou et al., *Semianalytical Production Simulation of Complex Hydraulic-Fracture Networks*, SPE Journal, February 2014, pp. 6–18；储层时间叠加见 Eqs. (2)–(3)，裂缝流动/中点压力见 Eqs. (4)、(6)，守恒见 Eq. (7)，参数见 Table 1，二维无限域情形见 Appendix A。代码从归一化二维扩散核独立推导系数，不是作者原代码，也未机械照抄附录印刷公式中的因子。

## 几何、未知量和单位

从左侧尖端向井编号，节点 p0、p1、p2、p3 的位置依次为 0、70、140、210 ft；p0 是尖端，p3 是井。网格中心为 35、105、175 ft。另一个翼由井位置 x=210 ft 镜像得到，延伸到 x=420 ft。

未知量顺序与原图完全相同：

`x = [p0, p1, p2, p3, qf1, qf2, qf3, Q1, Q2, Q3]`

- `qfj`：储层进入一个 panel 的单位裂缝长度体积流量，SI 为 m²/s。已经沿整个高度和两个裂缝面合计。它不是整个 panel 的流量，也不是 Darcy 速度。
- `Qj`：该 panel 尖端侧端点的裂缝轴向体积流量，SI 为 m³/s。`Q1=0`。
- `ell*qfj`：该 panel 的入流量。
- `Qwell_half = Q3 + ell*qf3 = ell*(qf1+qf2+qf3)`。
- `Qwell_total = 2*Qwell_half`。另一个翼的压力干扰不能只通过把产量乘 2 来代替。
- 所有求解器内部流量按地层体积计。导出流量为 STB/day，使用 `B=1.273` 换算。论文 Darcy 式带密度；这里把质量流量除以恒定密度，统一为体积流量，因此 `Rf=mu/(kf*w*h)`。

原图前四行准确说是边界条件/节点守恒：尖端零流量、两个内部节点守恒、井底压力边界。井口流量由上式求出。如果换成定产量，只替换第四行，不同时指定井底压力。

## 时间推进：必须保留历史

令 `Aij(t)` 是第 j 个 panel 从零时刻起持续单位入流，在 i 网格中心造成的压降响应；`A(0)=0`。它是**阶跃响应**，不是瞬时 Green 核。

在每个时间区间 `(t[m-1], t[m]]` 上令 `qf[m]` 为常数。在 `t[n]`：

```text
H[n] = sum(m=1..n-1) { A(t[n]-t[m-1]) - A(t[n]-t[m]) } @ qf[m]
p_center[n] = pi - H[n] - A(dt[n]) @ qf[n]
```

因此原来矩阵中的 `Aij` 替换为 `Aij(dt[n])`，而最后三个右端项由 `pi` 改成 `pi-H_i[n]`。Darcy 部分和节点守恒部分不变。不能在 t=1、2、3 等时刻分别用 `A(t) @ qf(t)` 独立求解，因为那相当于把当前流量错误地当成从零时刻起一直不变。

内部使用加密的对数时间网格，再把所需输出时刻插入网格；默认共 473 步。报告的 `qf[n]` 是当前整个小时间区间的常数近似。固定时间步、固定物性时整个系数矩阵也固定；非等间距步长下 `A(dt)` 随步长改变。

## 示例参数

| 参数 | 数值 | 来源 |
|---|---:|---|
| 储层渗透率 | 0.1 mD | Table 1 |
| 孔隙度 | 0.1 | Table 1 |
| 总压缩系数 | 3e-6 /psi | Table 1 |
| 黏度 | 0.6 cP | Table 1 |
| 高度 | 50 ft | Table 1 |
| 初始压力 | 4200 psi | Table 1 |
| 裂缝半长 | 210 ft | Table 1 |
| 裂缝导流能力 | 420 mD·ft | Table 1 |
| 体积系数 | 1.273 rb/STB | Table 1 |
| 固定井底压力 | 3000 psi | 本示例另设 |
| 可选固定总产量 | 25 STB/day，双翼合计 | Table 1 |

`Fcd=20`。默认沿用原矩阵的定井底压力工况，所以输出为递减产量；论文 Table 1 的 25 STB/day 工况使用 `control='rate'`，输出为递减井底压力。

## 结果文件

- `results/time_evolution.png`：所需时刻的裂缝压力曲线、panel 入流、总产量和节点压力随时间变化。
- `results/requested_times.csv`：所需时刻的压力、panel 入流和轴向流量。
- `results/full_time_history.csv`：全部内部时间步，包括启动阶段。
- `results/matrix_and_rhs_first_output.csv`：第一个输出时刻的实际矩阵和右端项，采用 psi、STB/day、ft，方便和原图核对。
- `results/solution_first_output.csv`：同一个时刻的未知量，顺序不变。
- `validation.json`：独立积分、历史叠加、显式双翼、方程残差、时间加密和空间敏感性结果。

## 已知的离散误差

三网格在启动最初几秒出现局部负入流和节点压力略高于初压，是这一粗网格中心配点离散的振荡，**不应解释为真实反向流动**。代码保留这些值并在 diagnostics 中标出，未把负流量强行截断。主图的历史窗口从首个输出时间的 1/10 开始，默认 0.1 h；全历史 CSV 仍从 1e-6 h 开始。

在本例所需的 1–60 h 时刻，panel 入流均为正。时间网格从每十倍时间 60 步加密为 120 步，总产量最大变化约 0.32%；半翼从 3 个 panel 改为 12 个，总产量最大变化约 2.94%。后者只是空间敏感性，不能称 12 网格已收敛。正式复现论文图件还要继续做空间收敛，并明确侧向边界、控制工况和流量单位。

改 `n_panels` 就能继续加密网格；同一套代码会自动把矩阵扩展成 `(3*N+1) × (3*N+1)`。保持 `n_panels=3` 时就是原来的 10×10 矩阵。
